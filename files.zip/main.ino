/*
  =====================================================================
  ENVIROGUARD IoT — Smart Environment & Safety Monitoring System
  Domain   : Embedded Systems & Internet of Things (IoT)
  Platform : ESP32
  Sensors  : DHT22 (Temperature/Humidity), PIR (Motion)
  Actuators: LED (visual alert), Buzzer (audible alert)
  Comms    : Wi-Fi + MQTT (Adafruit IO compatible)
  Flow     : SENSE -> PROCESS -> DECIDE -> ALERT -> CONNECT -> MONITOR
  =====================================================================

  SECURITY NOTE:
  Do NOT commit real Wi-Fi / MQTT / Adafruit IO credentials.
  Replace the placeholders below before flashing, and keep your real
  values out of anything you upload to GitHub.
*/

#include <WiFi.h>
#include <DHT.h>
#include <Adafruit_MQTT.h>
#include <Adafruit_MQTT_Client.h>

// ---------------------------------------------------------------
// 1. USER CONFIGURATION  (replace placeholders, never publish real values)
// ---------------------------------------------------------------
const char* WIFI_SSID      = "Wokwi-GUEST";     // Wokwi simulated AP; use your own SSID on real hardware
const char* WIFI_PASSWORD  = "";                 // Wokwi-GUEST needs no password

#define MQTT_SERVER   "io.adafruit.com"
#define MQTT_PORT     1883
const char* MQTT_USERNAME  = "YOUR_USERNAME";    // <-- placeholder, do not commit real value
const char* MQTT_KEY       = "YOUR_KEY";         // <-- placeholder, do not commit real value

// ---------------------------------------------------------------
// 2. PIN CONFIGURATION  (document your actual wiring here)
// ---------------------------------------------------------------
#define DHTPIN      15   // DHT22 DATA pin
#define DHTTYPE     DHT22
#define PIR_PIN     13   // PIR OUT pin
#define LED_PIN     2    // LED (through resistor) to GND
#define BUZZER_PIN  4    // Buzzer to GND

// ---------------------------------------------------------------
// 3. THRESHOLDS  (configurable demonstration values, not safety standards)
// ---------------------------------------------------------------
float TEMP_THRESHOLD    = 35.0;   // degrees C -> can be changed remotely (see Advanced Challenge)
float TEMP_WARNING_ONLY = 32.0;   // "WARNING" band before full "CRITICAL" alert

// ---------------------------------------------------------------
// 4. GLOBAL OBJECTS
// ---------------------------------------------------------------
DHT dht(DHTPIN, DHTTYPE);

WiFiClient client;
Adafruit_MQTT_Client mqtt(&client, MQTT_SERVER, MQTT_PORT, MQTT_USERNAME, MQTT_KEY);

Adafruit_MQTT_Publish tempFeed   = Adafruit_MQTT_Publish(&mqtt, MQTT_USERNAME "/feeds/enviroguard.temperature");
Adafruit_MQTT_Publish humFeed    = Adafruit_MQTT_Publish(&mqtt, MQTT_USERNAME "/feeds/enviroguard.humidity");
Adafruit_MQTT_Publish motionFeed = Adafruit_MQTT_Publish(&mqtt, MQTT_USERNAME "/feeds/enviroguard.motion");
Adafruit_MQTT_Publish alertFeed  = Adafruit_MQTT_Publish(&mqtt, MQTT_USERNAME "/feeds/enviroguard.alert");

// Optional: two-way command feed for remote threshold updates (Advanced Challenge)
Adafruit_MQTT_Subscribe thresholdCmd = Adafruit_MQTT_Subscribe(&mqtt, MQTT_USERNAME "/feeds/enviroguard.setthreshold");

// ---------------------------------------------------------------
// 5. SYSTEM STATE
// ---------------------------------------------------------------
enum SystemStatus { NORMAL, WARNING, CRITICAL };

unsigned long lastReadTime = 0;
const unsigned long READ_INTERVAL = 2500;   // ms between sensor reads / publishes

// ---------------------------------------------------------------
// SETUP
// ---------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println();
  Serial.println("================================");
  Serial.println("      ENVIROGUARD IoT");
  Serial.println("================================");

  pinMode(PIR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  dht.begin();

  connectWiFi();

  mqtt.subscribe(&thresholdCmd);
}

// ---------------------------------------------------------------
// MAIN LOOP
// ---------------------------------------------------------------
void loop() {
  MQTT_connect();
  handleIncomingCommands();

  unsigned long now = millis();
  if (now - lastReadTime >= READ_INTERVAL) {
    lastReadTime = now;
    runSenseProcessDecideAlertCycle();
  }

  // Keep the MQTT connection alive
  mqtt.processPackets(10);
  if (!mqtt.ping()) {
    mqtt.disconnect();
  }
}

// ---------------------------------------------------------------
// CORE CYCLE: SENSE -> PROCESS -> DECIDE -> ALERT -> CONNECT -> MONITOR
// ---------------------------------------------------------------
void runSenseProcessDecideAlertCycle() {

  // ---- SENSE ----
  float temperature = dht.readTemperature();
  float humidity     = dht.readHumidity();
  int motionRaw       = digitalRead(PIR_PIN);
  bool motionDetected  = (motionRaw == HIGH);

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Sensor reading failed. Check DHT22 wiring.");
    return;
  }

  // ---- PROCESS / DECIDE ----
  SystemStatus status = evaluateStatus(temperature);

  bool alertActive = (status != NORMAL);

  // ---- ALERT (local) ----
  digitalWrite(LED_PIN, alertActive ? HIGH : LOW);
  digitalWrite(BUZZER_PIN, (status == CRITICAL) ? HIGH : LOW);

  // ---- MONITOR (local Serial output) ----
  printStatusBlock(temperature, humidity, motionDetected, status);

  // ---- CONNECT (publish to MQTT / cloud) ----
  publishReadings(temperature, humidity, motionDetected, alertActive);
}

// ---------------------------------------------------------------
// DECISION LOGIC
// ---------------------------------------------------------------
SystemStatus evaluateStatus(float temperature) {
  if (temperature > TEMP_THRESHOLD) {
    return CRITICAL;
  } else if (temperature > TEMP_WARNING_ONLY) {
    return WARNING;
  }
  return NORMAL;
}

const char* statusToString(SystemStatus status) {
  switch (status) {
    case NORMAL:   return "NORMAL";
    case WARNING:  return "WARNING";
    case CRITICAL: return "CRITICAL";
  }
  return "UNKNOWN";
}

// ---------------------------------------------------------------
// SERIAL MONITOR OUTPUT
// ---------------------------------------------------------------
void printStatusBlock(float temperature, float humidity, bool motion, SystemStatus status) {
  Serial.println("================================");
  Serial.println("      ENVIROGUARD IoT");
  Serial.println("================================");
  Serial.print("Temperature : "); Serial.print(temperature); Serial.println(" C");
  Serial.print("Humidity    : "); Serial.print(humidity);    Serial.println(" %");
  Serial.print("Motion      : "); Serial.println(motion ? "DETECTED" : "CLEAR");
  Serial.print("Alert       : "); Serial.println(statusToString(status));
  if (status == CRITICAL) {
    Serial.println("!!! TEMPERATURE ALERT !!!");
  }
  Serial.println("================================");
}

// ---------------------------------------------------------------
// WI-FI CONNECTION
// ---------------------------------------------------------------
void connectWiFi() {
  Serial.print("Connecting to WiFi");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 40) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.println("WiFi Connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println();
    Serial.println("WiFi connection FAILED. Will retry in loop.");
  }
}

// ---------------------------------------------------------------
// MQTT CONNECTION (reconnect helper, Adafruit-style)
// ---------------------------------------------------------------
void MQTT_connect() {
  if (mqtt.connected()) {
    return;
  }

  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  Serial.print("Connecting to MQTT... ");
  int8_t ret;
  uint8_t retries = 3;
  while ((ret = mqtt.connect()) != 0) {
    Serial.println(mqtt.connectErrorString(ret));
    Serial.println("Retrying MQTT connection in 5 seconds...");
    mqtt.disconnect();
    delay(5000);
    retries--;
    if (retries == 0) {
      Serial.println("MQTT connection failed after retries. Continuing without cloud link.");
      return;
    }
  }
  Serial.println("MQTT Connected!");
}

// ---------------------------------------------------------------
// PUBLISH SENSOR DATA
// ---------------------------------------------------------------
void publishReadings(float temperature, float humidity, bool motion, bool alert) {
  if (!mqtt.connected()) {
    return; // Skip publish if not connected; local alert logic still runs
  }

  tempFeed.publish(temperature);
  humFeed.publish(humidity);
  motionFeed.publish(motion ? 1 : 0);
  alertFeed.publish(alert ? 1 : 0);
}

// ---------------------------------------------------------------
// OPTIONAL ADVANCED CHALLENGE: remote threshold update
// Subscribe to "enviroguard.setthreshold" and change TEMP_THRESHOLD live
// ---------------------------------------------------------------
void handleIncomingCommands() {
  Adafruit_MQTT_Subscribe *subscription;
  while ((subscription = mqtt.readSubscription(10))) {
    if (subscription == &thresholdCmd) {
      float newThreshold = atof((char *)thresholdCmd.lastread);
      if (newThreshold > 0) {
        TEMP_THRESHOLD = newThreshold;
        Serial.print("Remote command received. New TEMP_THRESHOLD = ");
        Serial.println(TEMP_THRESHOLD);
      }
    }
  }
}
