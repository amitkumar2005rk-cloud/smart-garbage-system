# ENVIROGUARD IoT
### Smart Environment & Safety Monitoring System
Embedded Systems & Internet of Things (IoT) — MainCrafts SkillSprint

---

## 1. Overview

ENVIROGUARD IoT is an ESP32-based prototype that senses environmental
conditions (temperature, humidity) and human presence (motion), decides
whether conditions are unsafe, triggers a local visual/audible alert, and
transmits the data over Wi-Fi/MQTT to a cloud dashboard for remote
monitoring.

**System flow:** `SENSE → PROCESS → DECIDE → ALERT → CONNECT → MONITOR`

---

## 2. Hardware

| Component        | Purpose                          |
|-------------------|-----------------------------------|
| ESP32             | Main controller, Wi-Fi connectivity |
| DHT22             | Temperature + humidity sensing    |
| PIR motion sensor | Presence / movement detection     |
| LED + resistor    | Visual alert indicator            |
| Buzzer            | Audible alert                     |

### Pin Map (edit to match your actual build)

| Signal        | ESP32 GPIO |
|---------------|------------|
| DHT22 DATA    | GPIO 15    |
| PIR OUT       | GPIO 13    |
| LED (+)       | GPIO 2     |
| Buzzer (+)    | GPIO 4     |

---

## 3. Software

- **Framework:** Arduino C/C++ on ESP32
- **Simulation:** [Wokwi](https://wokwi.com) (no hardware required)
- **Libraries used:**
  - `WiFi.h` (built-in, ESP32 core)
  - `DHT sensor library` + `Adafruit Unified Sensor`
  - `Adafruit MQTT Library` (`Adafruit_MQTT`, `Adafruit_MQTT_Client`)
- **Cloud platform:** Adafruit IO (MQTT)

Install the libraries via Arduino IDE → Library Manager: search for
"DHT sensor library", "Adafruit Unified Sensor", and "Adafruit MQTT Library".

---

## 4. How It Works

1. **SENSE** — Every ~2.5 s the ESP32 reads temperature/humidity from the
   DHT22 and motion state from the PIR sensor.
2. **PROCESS / DECIDE** — Temperature is compared against two configurable
   thresholds (`TEMP_WARNING_ONLY = 32°C`, `TEMP_THRESHOLD = 35°C`) to
   classify the system as `NORMAL`, `WARNING`, or `CRITICAL`.
3. **ALERT** — LED turns on for `WARNING`/`CRITICAL`; the buzzer only sounds
   at `CRITICAL`.
4. **CONNECT** — The ESP32 joins Wi-Fi (`Wokwi-GUEST` in simulation) and
   publishes readings as separate MQTT feeds:
   `enviroguard.temperature`, `enviroguard.humidity`,
   `enviroguard.motion`, `enviroguard.alert`.
5. **MONITOR** — Values appear on an Adafruit IO dashboard (or any
   MQTT-compatible dashboard) in near real time.

A remote-command subscription (`enviroguard.setthreshold`) is included as
the optional two-way-communication advanced challenge — publishing a number
to that feed updates `TEMP_THRESHOLD` on the device live.

---

## 5. Security Notes

- No real Wi-Fi password, MQTT username/key, or API token is committed to
  this repository. All credential fields in `src/main.ino` are placeholders
  (`YOUR_USERNAME`, `YOUR_KEY`, etc.) — replace them locally before flashing
  real hardware, and never commit the real values.

---

## 6. Testing

See `report/project-report.docx` §10 for the full 5-case test table
(normal temp, high temp, motion, no motion, Wi-Fi connect).

---

## 7. Repository Structure

```
ENVIROGUARD-IOT/
│
├── README.md
│
├── src/
│   └── main.ino
│
├── circuit/
│   └── circuit-diagram.svg
│
├── screenshots/
│   ├── sensor-output.png
│   ├── alert.png
│   └── dashboard.png
│
├── report/
│   └── project-report.docx
│
└── docs/
    └── architecture-diagram.svg
```

---

## 8. Limitations & Future Scope

- The 35°C threshold is a demonstration value, not a certified safety
  standard — a real deployment would need sensor calibration and
  domain-specific thresholds.
- Single-sensor-per-metric design; no redundancy or fault-tolerance.
- No on-device data logging (relies entirely on the cloud dashboard).
- Future scope: OLED local display, battery/solar power, multiple
  synchronized nodes, historical data analytics, and mobile push
  notifications.
